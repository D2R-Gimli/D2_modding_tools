CEL/CL2/GRP - Viewer Version 3.2
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Supported Files:

- CEL (Diablo - Graphx Format)
- CL2 (Diablo - Graphx Format)
- GRP (StarCraft - Graphx Format)
- TRN (Diablo Color Translation Table)
- PAL (Diablo Palette - File)

Output:

- BMP (Windows Bitmap-File)
- GIF (Compuserve GIF-Format <static>)
- GIF (Compuserve GIF-Format <Animation>)   !!! NEW !!!


Micky (a.k.a. Telamon)
21.02.1998

*** AND REMEMBER - REAL CODE IS TIMELESS !!! ***
** http://www.cs.tu-berlin.de/~mickyk/cv.html **
