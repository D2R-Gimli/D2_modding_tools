Hello everyone,
Across the history of Phrozen Keep there were many people who announced making .cof editor, but these projects were never finished. The only available tool is DOS-based cof editor which doesn't have interface and very limited functions. Today I'm presenting you The Ultimate COF Editor, "Coffee". COF editing has never been easier, now it's really like having a cup of coffee :) It was written by a programmer by the name "Hz" by my request and it's written in C++ (v.1.0 was based on Delphi). It can do everything you ever wanted to do with .cof files in real time, and also this tool can edit the Layer Priorities, which hasn't been possible before. On the screenshot you can see the explanation of the interface. 

This version has many new features:
Holding Left mouse button on the Animation preview window and move left/right � quickly rotate the directions.
Holding Middle mouse button on the Animation preview window and move left/right � increase/decrease the speed of animation.
Holding Right mouse button on the Animation preview window � move the image.
Double click on the Animation preview window � restore center position.
Left Click on the number next to the layer name � turn layer on/off
Middle Click on the layer name in The Layer Priorities section � fill the column with this layer.
Select one or more cells in The Layer Priorities section, then drag&drop with the right mouse button to swap the letter codes

[v.1.0 update]
labelled two unknown bytes;
added shadow to animation preview window;
added an option to play animation once or loop;
added bounding box display in animation preview window;
fixed some small bugs;
And also you can open .cof files directly from your folder, for example data\global\chars\so\SONUHTH.cof
When you press "Save" the program will create a backup file in the "Backup" folder.

[v.2.0 update]
the program was rewritten in C++. Fixed bugs related to launching and running. 

[v.2.1 update]
fixed one more minor bug. 